from re import IGNORECASE
# This Function can be called from any from any front end tool/website
import pandas as pd

def FunctionPredictResult(InputData):

    Num_Inputs=InputData.shape[0]

    # Making sure the input data has same columns as it was used for training the model
    # Also, if standardization/normalization was done, then same must be done for new input

    # Appending the new data with the Training data
    DataForML=pd.read_pickle('DataForML.pkl')
    #InputData=InputData.append(DataForML, ignore_index=True)
    InputData = pd.concat([InputData, DataForML], ignore_index=True)

    # Generating dummy variables for rest of the nominal variables
    InputData=pd.get_dummies(InputData)

    # Maintaining the same order of columns as it was during the model training
    Predictors=['rate','delivery']

    # Generating the input values to the model
    X=InputData[Predictors].values[0:Num_Inputs]

    ### Sandardization of data ###
    from sklearn.preprocessing import StandardScaler, MinMaxScaler
    # Choose either standardization or Normalization
    # On this data Min Max Normalization produced better results

    # Choose between standardization and MinMAx normalization
    # PredictorScaler=StandardScaler()
    PredictorScaler = MinMaxScaler()

    # Storing the fit object for later reference
    PredictorScalerFit = PredictorScaler.fit(X)

    # Generating the standardized values of X
    X = PredictorScalerFit.transform(X)

    # Loading the Function from pickle file
    import pickle
    with open('Final_XGB_Model.pkl', 'rb') as fileReadStream:
        PredictionModel=pickle.load(fileReadStream)
        # Don't forget to close the filestream!
        fileReadStream.close()

    # Genrating Predictions
    Prediction=PredictionModel.predict(X)
    PredictionResult=pd.DataFrame(Prediction, columns=['Prediction'])
    return(PredictionResult)
