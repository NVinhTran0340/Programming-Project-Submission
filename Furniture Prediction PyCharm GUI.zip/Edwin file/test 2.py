
import tkinter as tk
from tkinter import messagebox
from tkinter import scrolledtext
import pandas as pd
from Ffunction import FunctionPredictResult

class PredictApp:
    def __init__(self, root):
        self.root = root
        self.root.title('Furniture Price Forecast')

        # Create input box and label
        self.rate1_label = tk.Label(root, text='Rate 1 (0-5):')
        self.rate1_label.grid(row=0, column=0, padx=10, pady=5)
        self.rate1_entry = tk.Entry(root, width=10)
        self.rate1_entry.grid(row=0, column=1, padx=10, pady=5)

        self.rate2_label = tk.Label(root, text='Rate 2 (0-5):')
        self.rate2_label.grid(row=0, column=2, padx=10, pady=5)
        self.rate2_entry = tk.Entry(root, width=10)
        self.rate2_entry.grid(row=0, column=3, padx=10, pady=5)

        self.delivery1_label = tk.Label(root, text='Delivery 1 Cost:')
        self.delivery1_label.grid(row=1, column=0, padx=10, pady=5)
        self.delivery1_entry = tk.Entry(root, width=10)
        self.delivery1_entry.grid(row=1, column=1, padx=10, pady=5)

        self.delivery2_label = tk.Label(root, text='Delivery 2 Cost:')
        self.delivery2_label.grid(row=1, column=2, padx=10, pady=5)
        self.delivery2_entry = tk.Entry(root, width=10)
        self.delivery2_entry.grid(row=1, column=3, padx=10, pady=5)

        # Create a prediction button
        self.predict_button = tk.Button(root, text='Predict', command=self.get_prediction)
        self.predict_button.grid(row=2, columnspan=2, pady=20)

        # Create a result display area
        self.result_label = tk.Label(root, text='Prediction Result:')
        self.result_label.grid(row=3, column=0, padx=10, pady=5)
        self.result_text = scrolledtext.ScrolledText(root, width=40, height=10)
        self.result_text.grid(row=3, column=1, padx=10, pady=5)

    def get_prediction(self):
        try:
            # Get data from the input box
            rate_values = [float(self.rate1_entry.get()), float(self.rate2_entry.get())]
            delivery_values = [float(self.delivery1_entry.get()), float(self.delivery2_entry.get())]

            # 调用预测函数（假设 FunctionGeneratePrediction 已经更新为接受两个参数）
            input_data = pd.DataFrame(data={'rate': rate_values,'delivery': delivery_values})

            predictions = FunctionPredictResult(InputData=input_data)

            # 显示结果
            self.result_text.delete(1.0, tk.END)
            self.result_text.insert(tk.END, predictions)
        except ValueError:
            messagebox.showerror("Input Error", "Please enter valid numbers for Rate and Delivery Cost.")
        except Exception as e:
            messagebox.showerror("Error", str(e))

# Create the main window and run the application
if __name__ == '__main__':
    root = tk.Tk()
    app = PredictApp(root)
    root.mainloop()