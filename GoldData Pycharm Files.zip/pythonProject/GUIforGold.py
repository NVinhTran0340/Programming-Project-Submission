import tkinter as tk
import pandas as pd
from defpredict import FunctionPredictResult
class GoldPredictGUI:
    def __init__(self):
        # Create the main window widget.
        self.main_window = tk.Tk()
        self.main_window.title("Gold price prediction")

        # Label for High and Close:
        self.highLabel = tk.Label(text="High Column:")
        self.highLabel.grid(row = 0, column = 0, sticky = "E")
        self.closeLabel = tk.Label(text="Close Column:")
        self.closeLabel.grid(row = 1, column = 0, sticky = "E")

        # Entries for both:
        self.first_HighEntry = tk.Entry(width=10)
        self.first_HighEntry.grid(row=0, column=1)
        self.second_HighEntry = tk.Entry(width=10)
        self.second_HighEntry.grid(row=0, column=2)
        self.first_CloseEntry = tk.Entry(width=10)
        self.first_CloseEntry.grid(row=1, column=1)
        self.second_CloseEntry = tk.Entry(width=10)
        self.second_CloseEntry.grid(row=1, column=2)

        # A small big label for guiding the users:
        self.helpText=("*Enter data that matched the date for each\n"
                       " row as they required. Then hit the result once it is done!")
        self.helpLabel = tk.Label(text= self.helpText)
        self.helpLabel.grid(row=2, column=0, rowspan = 3)

        # Results label and text box:
        self.resultLbl = tk.Label(text = "Prediction:",relief="solid")
        self.resultLbl.grid(row=0,column=4,sticky="S")

        self.textResult = tk.Label(text="",relief="solid")
        self.textResult.grid(row=1,column=4,rowspan=2)

        #Button to print:
        self.outBtn = tk.Button(text="Print", command=self.OutputPredict)
        self.outBtn.grid(row=1, column=3,sticky="nsew")
        # Enter the tkinter main loop.
        tk.mainloop()


    def OutputPredict(self):
        # variables for the data:
        High_values = [float(self.first_HighEntry.get()),float(self.second_HighEntry.get())]
        Close_values = [float(self.first_CloseEntry.get()),float(self.second_CloseEntry.get())]

        # Add the data from high and close into the function
        input_data = pd.DataFrame(data={'High': High_values,'Close': Close_values})

        # Call the prediction function
        prediction_result = FunctionPredictResult(InputData=input_data)

        # Display the results through the widget
        result_text = prediction_result.to_string(index=False)
        self.textResult.config(text=result_text)


# Create an instance of the MyGUI class.
my_gui = GoldPredictGUI()
